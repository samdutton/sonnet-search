Shakespeare Sonnet Search
-------------------------

An instant search for William Shakespeare's sonnets, using Web SQL Database.